from dash import dcc, html, Input, Output, State, dash_table
import dash_bootstrap_components as dbc
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import io
import base64
import dash

# Initialize the Dash app
app = dash.Dash(_name_, external_stylesheets=[dbc.themes.BOOTSTRAP], suppress_callback_exceptions=True)
server = app.server  # For deployment

# Custom styles for the application
dashboard_colors = {
    "background": "#FFFFFF",  # White background
    "text": "#004D40",        # Dark turquoise text
    "card": "#F9F9F9",        # Light Grey Card Background
    "border": "#004D40",      # Dark turquoise border
    "button_light_turquoise": "#88D8C0",  # Light turquoise button
}

custom_styles = {
    "header": {
        "textAlign": "center",
        "color": dashboard_colors["text"],
        "fontSize": "40px",
        "fontWeight": "bold",
        "marginTop": "20px",
        "fontFamily": "monospace",
    },
    "upload": {
        "width": "100%",
        "height": "60px",
        "lineHeight": "60px",
        "borderWidth": "2px",
        "borderStyle": "dashed",
        "borderRadius": "15px",
        "textAlign": "center",
        "backgroundColor": dashboard_colors["card"],
        "color": dashboard_colors["text"],
        "fontWeight": "bold",
        "marginBottom": "20px",
        "fontFamily": "monospace",
    },
    "card": {
        "backgroundColor": dashboard_colors["card"],
        "padding": "20px",
        "borderRadius": "15px",
        "boxShadow": "0px 6px 15px rgba(0, 0, 0, 0.1)",
        "marginBottom": "20px",
        "border": f"1px solid {dashboard_colors['border']}",
        "fontFamily": "monospace",
    },
    "label": {
        "fontWeight": "bold",
        "color": dashboard_colors["text"],
        "fontFamily": "monospace",
    },
    "tab_style": {
        "backgroundColor": dashboard_colors["button_light_turquoise"],  # Light turquoise
        "color": dashboard_colors["text"],  # Dark turquoise font
        "fontWeight": "bold",
        "fontFamily": "monospace",
        "borderRadius": "15px",
        "padding": "10px",
    },
    "selected_tab_style": {
        "backgroundColor": dashboard_colors["text"],  # Dark turquoise for active tab
        "color": "#FFFFFF",  # White font for selected tab
        "fontWeight": "bold",
        "fontFamily": "monospace",
        "borderRadius": "15px",
        "padding": "10px",
    },
}

# Function for creating light-themed graphs
def create_light_graph(df, graph_type, x_axis=None, y_axis=None):
    figure = go.Figure()
    if graph_type == "scatter" and x_axis and y_axis:
        figure = px.scatter(df, x=x_axis, y=y_axis, color_discrete_sequence=["#A9A9A9"])
    elif graph_type == "bar" and x_axis and y_axis:
        figure = px.bar(df, x=x_axis, y=y_axis, color_discrete_sequence=["#A9A9A9"])
    elif graph_type == "histogram" and x_axis:
        figure = px.histogram(df, x=x_axis, color_discrete_sequence=["#A9A9A9"])
    elif graph_type == "line" and x_axis and y_axis:
        figure = px.line(df, x=x_axis, y=y_axis, color_discrete_sequence=["#A9A9A9"])

    figure.update_layout(
        plot_bgcolor="#F9F9F9",
        paper_bgcolor="#FFFFFF",
        font=dict(color="#004D40"),
        title=dict(text="Customized Visualization", x=0.5, font=dict(size=18, color="#004D40"))
    )
    return figure

# Tab Layouts
dashboard_layout = html.Div([
    html.H1("Visualization Orchestrator", style=custom_styles["header"]),
    dcc.Upload(
        id="upload-data",
        children=html.Div(["Drag and Drop or ", html.A("Select a File")]),
        style=custom_styles["upload"],
        multiple=False,
    ),
    html.Div(id="data-preview", style={"marginBottom": "20px"}),
    dbc.Row([
        dbc.Col(html.Div([html.Label("Select X-axis:", style=custom_styles["label"]),
                          dcc.Dropdown(id="x-axis", placeholder="Select column for X-axis")],
                         style=custom_styles["card"])),
        dbc.Col(html.Div([html.Label("Select Y-axis:", style=custom_styles["label"]),
                          dcc.Dropdown(id="y-axis", placeholder="Select column for Y-axis")],
                         style=custom_styles["card"])),
        dbc.Col(html.Div([html.Label("Select Graph Type:", style=custom_styles["label"]),
                          dcc.Dropdown(
                              id="graph-type",
                              options=[
                                  {"label": "Scatter Plot", "value": "scatter"},
                                  {"label": "Bar Chart", "value": "bar"},
                                  {"label": "Histogram", "value": "histogram"},
                                  {"label": "Line Chart", "value": "line"}
                              ],
                              value="scatter",
                              placeholder="Select graph type"
                          )],
                         style=custom_styles["card"])),
    ]),
    html.Div([dcc.Graph(id="data-graph")], style=custom_styles["card"]),
])

feedback_layout = html.Div([
    html.H1("Feedback", style=custom_styles["header"]),
    html.Div([
        dbc.Textarea(placeholder="Provide your feedback here...", style={"width": "100%", "height": "200px"}),
        dbc.Button("Submit Feedback", color="success", style={"marginTop": "10px"}),
    ], style=custom_styles["card"]),
])

# Statistical Insights Layout and Callback
statistical_insights_layout = html.Div([
    html.H1("Statistical Insights", style=custom_styles["header"]),
    html.Div(id="statistical-insights-content", style=custom_styles["card"]),
])

@app.callback(
    Output("statistical-insights-content", "children"),
    [Input("upload-data", "contents")],
    [State("upload-data", "filename")]
)
def update_statistical_insights(contents, filename):
    if contents is None:
        return "No file uploaded yet. Please upload a file to see insights."

    df = parse_contents(contents, filename)
    if df is None:
        return "Error: Unsupported file format or corrupted file."

    # Compute Statistics
    numerical_columns = df.select_dtypes(include=["number"]).columns
    if numerical_columns.empty:
        return "No numerical data available for statistical insights."

    stats = df[numerical_columns].describe().T
    stats["mode"] = df[numerical_columns].mode().iloc[0]  # Mode is often more than one value; take the first.
    stats = stats.rename(
        columns={
            "mean": "Mean",
            "std": "Std Dev",
            "min": "Min",
            "25%": "25th Percentile",
            "50%": "Median",
            "75%": "75th Percentile",
            "max": "Max",
        }
    )

    # Create correlation matrix
    corr_matrix = df[numerical_columns].corr()

    # Layout for statistics
    statistics_table = dash_table.DataTable(
        data=stats.reset_index().to_dict("records"),
        columns=[{"name": col, "id": col} for col in stats.reset_index().columns],
        style_table={"overflowX": "auto"},
        style_cell={"textAlign": "center", "fontFamily": "monospace"},
    )

    # Correlation heatmap
    corr_figure = px.imshow(
        corr_matrix,
        text_auto=True,
        color_continuous_scale="turbo",
        title="Correlation Matrix",
    )
    corr_figure.update_layout(
        paper_bgcolor=dashboard_colors["card"],
        plot_bgcolor=dashboard_colors["background"],
    )

    # Display numerical columns summary
    summary_content = html.Div([
        html.Label("Summary Statistics", style=custom_styles["label"]),
        statistics_table,
        html.Br(),
        dcc.Graph(figure=corr_figure)
    ], style=custom_styles["card"])

    return summary_content

about_layout = html.Div([
    html.H1("About", style=custom_styles["header"]),
    html.Div("This application by A~I~A is built to visualize data and perform exploratory data analysis.", style=custom_styles["card"]),
])

help_layout = html.Div([
    html.H1("Help", style=custom_styles["header"]),
    html.Div("Upload a CSV or Excel file to start analyzing your data.", style=custom_styles["card"]),
])

# Main App Layout with all Tabs
app.layout = dbc.Container([
    dcc.Tabs(
        children=[
            dcc.Tab(label="Dashboard", children=dashboard_layout, style=custom_styles["tab_style"], selected_style=custom_styles["selected_tab_style"]),
            dcc.Tab(label="Feedback", children=feedback_layout, style=custom_styles["tab_style"], selected_style=custom_styles["selected_tab_style"]),
            dcc.Tab(label="Statistical Insights", children=statistical_insights_layout, style=custom_styles["tab_style"], selected_style=custom_styles["selected_tab_style"]),
            dcc.Tab(label="About", children=about_layout, style=custom_styles["tab_style"], selected_style=custom_styles["selected_tab_style"]),
            dcc.Tab(label="Help", children=help_layout, style=custom_styles["tab_style"], selected_style=custom_styles["selected_tab_style"]),
        ]
    )
], fluid=True)

# Helper function to parse uploaded content
def parse_contents(contents, filename):
    try:
        content_type, content_string = contents.split(',')
        decoded = base64.b64decode(content_string)
        if filename.endswith('.csv'):
            return pd.read_csv(io.StringIO(decoded.decode('utf-8')))
        elif filename.endswith('.xlsx'):
            return pd.read_excel(io.BytesIO(decoded))
        else:
            return None
    except Exception as e:
        print(f"Error parsing file: {e}")
        return None

# Callback for dataset handling and visualization
@app.callback(
    [Output("data-preview", "children"),
     Output("x-axis", "options"),
     Output("y-axis", "options"),
     Output("data-graph", "figure")],
    [Input("upload-data", "contents"),
     Input("x-axis", "value"),
     Input("y-axis", "value"),
     Input("graph-type", "value")],
    [State("upload-data", "filename")]
)
def update_dashboard(contents, x_axis, y_axis, graph_type, filename):
    if contents is None:
        return "No file uploaded yet.", [], [], go.Figure()

    df = parse_contents(contents, filename)
    if df is None:
        return "Error: Unsupported file format or corrupted file.", [], [], go.Figure()

    preview_table = dash_table.DataTable(
        data=df.head().to_dict('records'),
        columns=[{"name": col, "id": col} for col in df.columns],
        style_table={"overflowX": "auto"},
    )

    dropdown_options = [{"label": col, "value": col} for col in df.columns]

    # Ensure that if no valid x or y axis is selected, we return an empty graph
    if x_axis is None or y_axis is None or graph_type is None:
        return preview_table, dropdown_options, dropdown_options, go.Figure()

    figure = create_light_graph(df, graph_type, x_axis, y_axis)

    return preview_table, dropdown_options, dropdown_options, figure

if _name_ == "_main_":
    app.run_server(debug=True)